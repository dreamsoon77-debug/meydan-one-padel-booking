Meydan One Live Padel Website

How to open:
1. Open index.html in any browser.
2. It works immediately on the same device.
3. Bookings are saved in the browser local storage.
4. Admin can export bookings as CSV.

Important limitation:
This is a single-file website. For residents to open it by QR Code, upload index.html to any public/internal hosting platform and generate a QR Code from that URL.

Suggested hosting options:
- Company approved hosting
- Azure Static Web Apps
- SharePoint/Power Pages via IT
- Netlify drag-and-drop for testing only
